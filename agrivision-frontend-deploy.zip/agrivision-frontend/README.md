# AgriVision AI — Crop Health Frontend

React + Vite + Leaflet frontend for the `crop_health_solid` FastAPI backend.

1. Mark 4 corner points on the map (Undo / Clear available)
2. Pick start and end dates (presets, max 31 days — the backend limit)
3. Analyze → results panel: health score, satellite photos (overlay on map), NDVI stats, advisory, notification status

## Run

```bash
cp .env.example .env       # set CROP_HEALTH_PROXY_TARGET to your backend (default http://localhost:8000)
npm install
npm run dev
```

Start the backend first (`uvicorn app.main:app --reload`). In dev, Vite proxies `/fields`, `/jobs`, `/healthz`.

## API used (src/api/cropHealth.js)

| Action | Call |
|---|---|
| Server check | `GET /healthz` |
| Register polygon | `POST /fields` |
| Start analysis | `POST /jobs/crop-health/start` → `{ job_id }` |
| Poll | `GET /jobs/crop-health/jobs/{job_id}` |
| Last result | `GET /jobs/crop-health/fields/{field_id}/latest` |

## Production

`npm run build`, set `VITE_API_BASE_URL`, and list your site in the backend's `CORS_ALLOW_ORIGINS`.
