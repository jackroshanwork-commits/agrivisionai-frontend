import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// In dev, forward API calls to the deployed crop-health server so the browser
// sees them as same-origin (no CORS needed while developing).
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const target = env.CROP_HEALTH_PROXY_TARGET || 'http://localhost:8000';
  const proxy = { target, changeOrigin: true, timeout: 600000, proxyTimeout: 600000 };

  return {
    plugins: [react()],
    server: {
      proxy: {
        '/fields': proxy,
        '/jobs': proxy,
        '/healthz': proxy,
      },
    },
  };
});
