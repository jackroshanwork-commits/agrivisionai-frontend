import { useMemo, useRef, useState } from 'react';
import FieldMap from './components/FieldMap.jsx';
import { useServerHealth, ServerBadge, ServerGate } from './ServerStatus.jsx';
import StartPage from './StartPage.jsx';
import { registerField, startCropHealth, getJob, getLatestResult } from './api/cropHealth.js';

const MAX_POINTS = 4;
const MAX_RANGE_DAYS = 31; // backend limit (MAX_RANGE_DAYS)
// Map start position. Override with VITE_MAP_CENTER="lat,lng" in .env
const DEFAULT_CENTER = (import.meta.env.VITE_MAP_CENTER || '13.0827,80.2707')
  .split(',')
  .map(Number)
  .slice(0, 2);
const PRESETS = [
  { label: 'Last 7 days', days: 7 },
  { label: 'Last 15 days', days: 15 },
  { label: 'Last 30 days', days: 30 },
];
const dayCount = (a, b) => Math.round((new Date(b) - new Date(a)) / 86400000) + 1;

const POLL_MS = 3000;
const MAX_WAIT_MS = 10 * 60 * 1000;
const MAX_POLL_FAILS = 5;
const MAX_BUSY_RETRIES = 4;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const isoDate = (d) => d.toISOString().slice(0, 10);
const today = () => isoDate(new Date());
const daysAgo = (n) => {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return isoDate(d);
};

const RISK_COLORS = {
  low: '#2f6b3a',
  moderate: '#b8860b',
  high: '#d2691e',
  critical: '#b22222',
};

function scoreLabel(score) {
  if (score >= 70) return 'Healthy';
  if (score >= 40) return 'Needs attention';
  return 'Poor';
}

const fmtTime = (t) => (t ? new Date(t).toLocaleString() : '-');

function scoreColor(score) {
  if (score >= 70) return '#2f6b3a';
  if (score >= 40) return '#b8860b';
  return '#b22222';
}

// Keep the raw-response viewer readable: don't print the whole base64 image.
const hideImageData = (key, value) =>
  (key === 'satellite_image_data_url' || key === 'data_url') && value ? `<${value.length} chars of image data>` : value;

const fmt = (n, digits = 3) => (typeof n === 'number' ? n.toFixed(digits) : '-');

export default function App() {
  const [points, setPoints] = useState([]);
  const [startDate, setStartDate] = useState(daysAgo(15));
  const [endDate, setEndDate] = useState(today());
  const [existingFieldId, setExistingFieldId] = useState('');
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState(null); // CropHealthJobResult (or { health_score } from /latest)
  const [fieldId, setFieldId] = useState('');
  // Remember which polygon a registered field_id belongs to, so re-running the
  // same drawing doesn't create duplicate fields on the server.
  const [registered, setRegistered] = useState({ key: '', fieldId: '' });
  const runId = useRef(0);
  const server = useServerHealth(); // is the backend API running?
  const [started, setStarted] = useState(false); // false = show the start page
  const [showOnMap, setShowOnMap] = useState(false);
  const [overlayOpacity, setOverlayOpacity] = useState(0.9);
  const [shownIndex, setShownIndex] = useState(0); // which photo is drawn on the map

  // The Sentinel-2 photo from the job result, if it has one: { url, bounds }.
  const satelliteImages = useMemo(() => {
    const hs = result?.health_score;
    if (!hs) return [];
    if (Array.isArray(hs.satellite_images) && hs.satellite_images.length) {
      return hs.satellite_images
        .filter((i) => i.data_url && i.bounds)
        .map((i) => ({ url: i.data_url, bounds: i.bounds, date: i.scene_date, cloud: i.cloud_cover_pct }));
    }
    if (hs.satellite_image_data_url && hs.satellite_image_bounds) {
      return [
        {
          url: hs.satellite_image_data_url,
          bounds: hs.satellite_image_bounds,
          date: hs.satellite_image_scene_date,
          cloud: hs.satellite_image_cloud_cover_pct,
        },
      ];
    }
    return [];
  }, [result]);
  const shownImage = satelliteImages[Math.min(shownIndex, satelliteImages.length - 1)] ?? null;

  const pointsKey = JSON.stringify(points);
  const rangeDays = startDate && endDate ? dayCount(startDate, endDate) : 0;
  const datesValid = startDate && endDate && startDate <= endDate && rangeDays <= MAX_RANGE_DAYS;
  const hasTarget = points.length === MAX_POINTS || existingFieldId.trim() !== '';
  const canRun = hasTarget && datesValid && !isLoading && server.online;

  function handlePointsChange(newPoints) {
    setPoints(newPoints);
    setResult(null);
    setError('');
    setStatus(
      newPoints.length < MAX_POINTS
        ? `${newPoints.length} of ${MAX_POINTS} points placed.`
        : 'Field marked. Ready to analyze.'
    );
  }

  function handleUndo() {
    if (points.length) handlePointsChange(points.slice(0, -1));
  }

  function handleReset() {
    runId.current += 1;
    setIsLoading(false);
    setPoints([]);
    setResult(null);
    setError('');
    setStatus('');
  }

  // Use the typed field id if present, otherwise register the drawn polygon.
  async function resolveFieldId() {
    const typed = existingFieldId.trim();
    if (typed) return typed;
    if (registered.key === pointsKey && registered.fieldId) return registered.fieldId;
    setStatus('Registering field…');
    const created = await registerField(points);
    setRegistered({ key: pointsKey, fieldId: created.field_id });
    return created.field_id;
  }

  async function startWithRetry(id, myRun) {
    let hiccups = 0;
    for (let attempt = 0; ; attempt++) {
      try {
        return await startCropHealth(id, startDate, endDate);
      } catch (err) {
        if (runId.current !== myRun) throw err;
        const busy = err.status === 429;
        const transient = !err.status || err.status >= 500;
        if (busy && attempt < MAX_BUSY_RETRIES) {
          setStatus('The server is busy with another analysis — waiting for a free slot…');
          await sleep(10000);
        } else if (transient && hiccups < 2) {
          hiccups += 1;
          setStatus('Connection hiccup — retrying…');
          await sleep(3000);
        } else {
          throw err;
        }
      }
    }
  }

  async function waitForJob(jobId, myRun) {
    const t0 = Date.now();
    let fails = 0;
    while (runId.current === myRun) {
      await sleep(POLL_MS);
      if (runId.current !== myRun) return null;
      const secs = Math.round((Date.now() - t0) / 1000);
      try {
        const job = await getJob(jobId);
        fails = 0;
        if (job.status !== 'running') return job;
        setStatus(`Analyzing satellite imagery… ${secs}s (This will take couple of minutes)`);
      } catch (err) {
        fails += 1;
        if (err.status === 404 || fails >= MAX_POLL_FAILS) throw err;
        setStatus('Reconnecting to the server…');
      }
      if (Date.now() - t0 > MAX_WAIT_MS) {
        throw new Error(
          'This is taking longer than expected. The analysis may still finish — try "Load last result" in a few minutes.'
        );
      }
    }
    return null;
  }

  async function handleAnalyze() {
    const myRun = ++runId.current;
    setIsLoading(true);
    setError('');
    setResult(null);
    try {
      const id = await resolveFieldId();
      setFieldId(id);
      setStatus('Starting analysis…');
      const queued = await startWithRetry(id, myRun);
      setStatus('Analyzing satellite imagery… (This will take couple of minutes)');
      const job = await waitForJob(queued.job_id, myRun);
      if (job === null) return;
      setResult(job);
      setStatus(job.status === 'succeeded' ? 'Done.' : '');
    } catch (err) {
      if (runId.current !== myRun) return;
      setError(err.message);
      setStatus('');
    } finally {
      if (runId.current === myRun) setIsLoading(false);
    }
  }

  async function handleLoadLatest() {
    const id = existingFieldId.trim() || (registered.key === pointsKey ? registered.fieldId : '');
    if (!id) {
      setError('No field to look up yet — run an analysis first, or paste a Field ID.');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      setFieldId(id);
      const data = await getLatestResult(id);
      setResult(data);
      setStatus('Loaded last successful result.');
    } catch (err) {
      setError(
        err.status === 404
          ? 'No saved result for this field yet. Run "Analyze Crop Health" first.'
          : err.message
      );
    } finally {
      setIsLoading(false);
    }
  }

  if (!started) return <StartPage server={server} onStart={() => setStarted(true)} />;

  return (
    <div className="app">
      <header className="app-header">
        <h1>AgriVision AI — Crop Health Monitor</h1>
        <p>Mark a field on the map, then run the satellite crop-health check.</p>
        <ServerBadge server={server} />
      </header>

      <div className="layout">
        <div className="map-wrapper">
          <FieldMap
            points={points}
            onPointsChange={handlePointsChange}
            center={DEFAULT_CENTER}
            satelliteOverlay={showOnMap ? shownImage : null}
            overlayOpacity={overlayOpacity}
          />
        </div>

        <aside className="panel">
          {!server.everOnline ? (
            <ServerGate server={server} />
          ) : (
            <>
          {server.state === 'offline' && (
            <p className="field-error">
              Lost connection to the server - reconnecting automatically. Analysis is paused until it is back.
            </p>
          )}
          <h2>1. Mark your field</h2>
          <p className="instructions">
            Click on the map to drop <strong>4 corner points</strong> around your field.
          </p>
          <ol className="point-list">
            {points.map((p, i) => (
              <li key={i}>
                Lat {p[0].toFixed(5)}, Lng {p[1].toFixed(5)}
              </li>
            ))}
          </ol>
          <div className="btn-row">
            <button className="btn btn-secondary" onClick={handleUndo} disabled={isLoading || !points.length}>
              Undo last point
            </button>
            <button className="btn btn-secondary" onClick={handleReset} disabled={isLoading}>
              Clear area
            </button>
          </div>

          <h2 style={{ marginTop: 24 }}>2. Analysis period</h2>
          <p className="instructions">Satellite scenes inside this range are combined into one score.</p>

          <div className="preset-row">
            {PRESETS.map((p) => (
              <button
                key={p.days}
                type="button"
                className="chip"
                onClick={() => {
                  setStartDate(daysAgo(p.days - 1));
                  setEndDate(today());
                }}
              >
                {p.label}
              </button>
            ))}
          </div>

          <label>Start date</label>
          <input
            type="date"
            className="date-input"
            value={startDate}
            max={today()}
            onChange={(e) => setStartDate(e.target.value)}
          />
          <label style={{ marginTop: 12, display: 'block' }}>End date</label>
          <input
            type="date"
            className="date-input"
            value={endDate}
            max={today()}
            onChange={(e) => setEndDate(e.target.value)}
          />
          {startDate > endDate && <p className="field-error">Pick a start date on or before the end date.</p>}
          {startDate <= endDate && rangeDays > MAX_RANGE_DAYS && (
            <p className="field-error">
              The server accepts at most {MAX_RANGE_DAYS} days (you chose {rangeDays}).
            </p>
          )}
          {datesValid && <p className="instructions">Selected period: {rangeDays} day{rangeDays === 1 ? '' : 's'}.</p>}

          <label style={{ marginTop: 12, display: 'block' }}>Existing Field ID (optional)</label>
          <input
            type="text"
            className="date-input"
            placeholder="Leave blank to use the polygon above"
            value={existingFieldId}
            onChange={(e) => setExistingFieldId(e.target.value)}
          />

          <h2 style={{ marginTop: 24 }}>3. Run analysis</h2>
          <button className="btn btn-primary" onClick={handleAnalyze} disabled={!canRun}>
            {isLoading ? 'Working…' : 'Analyze Crop Health'}
          </button>
          <button className="btn btn-secondary" onClick={handleLoadLatest} disabled={isLoading}>
            Load last result
          </button>

          {status && <p className="status">{status}</p>}
          {error && <p className="field-error">{error}</p>}

          {result && (
            <ResultsPanel
              data={result}
              fieldId={fieldId}
              satelliteImages={satelliteImages}
              shownIndex={shownIndex}
              onShownIndexChange={setShownIndex}
              outline={
                registered.fieldId && registered.fieldId === result.field_id && points.length === MAX_POINTS
                  ? points
                  : null
              }
              showOnMap={showOnMap}
              onShowOnMapChange={setShowOnMap}
              overlayOpacity={overlayOpacity}
              onOverlayOpacityChange={setOverlayOpacity}
            />
          )}
            </>
          )}
        </aside>
      </div>
    </div>
  );
}

/**
 * Renders a CropHealthJobResult:
 *   { job_id, field_id, status, health_score{...}, reasoning{...}, notification, error, started_at, finished_at }
 * The /latest endpoint returns the stored JSON, which has `health_score` but may lack `reasoning`.
 */
function ResultsPanel({
  data,
  fieldId,
  satelliteImages,
  shownIndex,
  onShownIndexChange,
  outline,
  showOnMap,
  onShowOnMapChange,
  overlayOpacity,
  onOverlayOpacityChange,
}) {
  const hs = data.health_score;
  const rs = data.reasoning;
  const failed = data.status === 'failed';

  return (
    <div className="results">
      {data.error && (
        <p className="field-error">
          {failed && hs ? 'Showing the last successful score. ' : ''}
          {data.error}
        </p>
      )}

      {hs && (
        <>
          <h3>Health Score</h3>
          <div className="score-card">
            <div className="score-number" style={{ color: scoreColor(hs.health_score) }}>
              {Math.round(hs.health_score)}
              <span> / 100</span>
              <em className="score-label" style={{ color: scoreColor(hs.health_score) }}>
                {scoreLabel(hs.health_score)}
              </em>
            </div>
            <div className="score-bar">
              <div
                className="score-bar-fill"
                style={{ width: `${Math.max(0, Math.min(100, hs.health_score))}%`, background: scoreColor(hs.health_score) }}
              />
            </div>
          </div>

          <h3>Satellite Images of Your Field</h3>
          {satelliteImages.length > 0 ? (
            <>
              <div className="sat-grid">
                {satelliteImages.map((img, i) => (
                  <figure key={i} className={`sat-card${showOnMap && shownIndex === i ? ' sat-card-active' : ''}`}>
                    <div className="sat-frame">
                      <img className="sat-image" src={img.url} alt={`Satellite photo ${i + 1} of your field`} />
                      {outline && <FieldOutline points={outline} bounds={img.bounds} />}
                    </div>
                    <figcaption>
                      <strong>{img.date || `Photo ${i + 1}`}</strong>
                      {typeof img.cloud === 'number' && ` · ${Math.round(img.cloud)}% cloud`}
                    </figcaption>
                    <label className="sat-control">
                      <input
                        type="checkbox"
                        checked={showOnMap && shownIndex === i}
                        onChange={(e) => {
                          if (e.target.checked) onShownIndexChange(i);
                          onShowOnMapChange(e.target.checked);
                        }}
                      />{' '}
                      Show on map
                    </label>
                    <a className="sat-download" href={img.url} download={`field-satellite-${img.date || i + 1}.jpg`}>
                      Download image
                    </a>
                  </figure>
                ))}
              </div>
              <p className="instructions">
                Sentinel-2 satellite photos, one for each pass used in the score. Each pixel is about 10 m, so they
                show field patterns rather than individual plants.
                {hs.scenes_used && hs.scenes_used.length > satelliteImages.length &&
                  ` The score used ${hs.scenes_used.length} passes; photos are shown for the ${satelliteImages.length} most recent.`}
              </p>
              {showOnMap && (
                <label className="sat-control">
                  Transparency
                  <input
                    type="range"
                    min="0.2"
                    max="1"
                    step="0.05"
                    value={overlayOpacity}
                    onChange={(e) => onOverlayOpacityChange(Number(e.target.value))}
                  />
                </label>
              )}
            </>
          ) : (
            <p className="instructions">
              {failed
                ? 'No satellite image is available for this run.'
                : 'No satellite image was available for this run (the score above is still valid). Try running the analysis again.'}
            </p>
          )}

          <h3>NDVI Summary</h3>
          <dl className="stat-grid">
            <dt>Mean NDVI</dt>
            <dd>{fmt(hs.ndvi_mean)}</dd>
            <dt>Min NDVI</dt>
            <dd>{fmt(hs.ndvi_min)}</dd>
            <dt>Max NDVI</dt>
            <dd>{fmt(hs.ndvi_max)}</dd>
            <dt>Period</dt>
            <dd>
              {hs.period_start} → {hs.period_end}
            </dd>
            <dt>Cloud cover</dt>
            <dd>{fmt(hs.cloud_cover_pct, 1)}%</dd>
            <dt>Scenes used</dt>
            <dd>{hs.scenes_used?.length ?? 0}</dd>
            <dt>Cropland mask</dt>
            <dd>{hs.cropland_mask_source}</dd>
          </dl>

          {/^https?:\/\//.test(hs.ndvi_tile_url || '') && (
            <p>
              <a href={hs.ndvi_tile_url} target="_blank" rel="noreferrer">
                Download NDVI map
              </a>
            </p>
          )}
        </>
      )}

      {rs && (
        <>
          <h3>Advisory</h3>
          <p>
            <span className="risk-badge" style={{ background: RISK_COLORS[rs.risk_level] || '#555' }}>
              {rs.risk_level} risk
            </span>{' '}
            <small>
              confidence {Math.round((rs.confidence ?? 0) * 100)}% · {rs.generated_by}
            </small>
          </p>
          <dl className="stat-grid">
            <dt>Likely cause</dt>
            <dd>{rs.likely_cause}</dd>
            <dt>Recommended action</dt>
            <dd>{rs.recommended_action}</dd>
          </dl>
          {rs.message_farmer_language && (
            <p className="farmer-message" style={{ whiteSpace: 'pre-wrap' }}>
              {rs.message_farmer_language}
            </p>
          )}
        </>
      )}

      {data.notification && (
        <>
          <h3>Farmer notification</h3>
          <p>
            <span className={`pill ${data.notification.delivered ? 'pill-ok' : 'pill-off'}`}>
              {data.notification.delivered ? 'Sent' : 'Not sent'}
            </span>{' '}
            {data.notification.error && <small>{data.notification.error}</small>}
          </p>
        </>
      )}

      {!hs && !data.error && <p>No health score in this response.</p>}

      <details style={{ marginTop: 12 }}>
        <summary>Job details &amp; raw response</summary>
        <p className="instructions">
          Field ID: <code>{fieldId || data.field_id}</code>
          <br />
          Job ID: <code>{data.job_id}</code>
          <br />
          Status: {data.status}
          <br />
          Started: {fmtTime(data.started_at)} · Finished: {fmtTime(data.finished_at)}
        </p>
        <pre>{JSON.stringify(data, hideImageData, 2)}</pre>
      </details>
    </div>
  );
}

/** Draws the field's polygon on top of the satellite photo, so people can see where it sits. */
function FieldOutline({ points, bounds }) {
  const [[south, west], [north, east]] = bounds;
  const toXY = ([lat, lng]) =>
    `${(((lng - west) / (east - west)) * 100).toFixed(2)},${(((north - lat) / (north - south)) * 100).toFixed(2)}`;
  return (
    <svg className="sat-outline" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
      <polygon points={points.map(toXY).join(' ')} />
    </svg>
  );
}
