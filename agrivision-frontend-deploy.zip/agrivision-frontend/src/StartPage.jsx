/**
 * Landing page. Checks the backend (GET /healthz, via useServerHealth) and only
 * lets the user into the app when it is running.
 */
const STEPS = [
  { icon: '🗺️', title: 'Mark your field', text: 'Drop 4 corner points on the map.' },
  { icon: '📅', title: 'Pick the dates', text: 'Choose the period you want checked.' },
  { icon: '🛰️', title: 'Get your report', text: 'Health score, satellite photo and advice.' },
];

export default function StartPage({ server, onStart }) {
  const checking = server.state === 'checking';
  const online = server.state === 'online';
  const offline = server.state === 'offline';

  return (
    <div className="sp-page">
      <div className="sp-card">
        <h1 className="sp-title">AgriVision AI</h1>
        <p className="sp-tagline">Crop Health Monitor - see how your field looks from space.</p>

        <div className="sp-steps">
          {STEPS.map((s, i) => (
            <div className="sp-step" key={s.title}>
              <div className="sp-step-icon">{s.icon}</div>
              <div className="sp-step-title">
                {i + 1}. {s.title}
              </div>
              <div className="sp-step-text">{s.text}</div>
            </div>
          ))}
        </div>

        <div className={`sp-status sp-status-${server.state}`} role="status">
          <span className="sp-dot" />
          {checking && <span>Checking that the server is running…</span>}
          {online && <span>The server is running. You are ready to go.</span>}
          {offline && <span>The server is not running right now.</span>}
        </div>

        {offline && (
          <p className="sp-help">
            {server.reason} We can't start a crop-health check until it is back. We are checking again automatically,
            so you can leave this page open.
          </p>
        )}

        <button className="sp-start" onClick={onStart} disabled={!online}>
          {checking ? 'Checking…' : online ? 'Start  →' : 'Server unavailable'}
        </button>

        {offline && (
          <button className="sp-retry" onClick={server.retry} disabled={server.busy}>
            {server.busy ? 'Checking…' : 'Try again now'}
          </button>
        )}
      </div>
    </div>
  );
}
