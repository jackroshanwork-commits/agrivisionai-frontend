import { useCallback, useEffect, useRef, useState } from 'react';
import { API_BASE } from './api/cropHealth.js';

const HEALTH_TIMEOUT_MS = 8000; // how long we wait for /healthz to answer
const RECHECK_ONLINE_MS = 30000; // keep an eye on the server while it is up
const RECHECK_OFFLINE_MS = 5000; // retry quickly while it is down

/** Calls GET /healthz. Resolves { ok: true } or { ok: false, reason } - never throws. */
async function pingServer() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HEALTH_TIMEOUT_MS);
  try {
    const res = await fetch(`${API_BASE}/healthz`, { signal: controller.signal, cache: 'no-store' });
    if (!res.ok) return { ok: false, reason: `The server answered with an error (status ${res.status}).` };
    const data = await res.json().catch(() => null);
    if (data?.status !== 'ok') return { ok: false, reason: 'The server gave an unexpected answer.' };
    return { ok: true };
  } catch (err) {
    return {
      ok: false,
      reason: err.name === 'AbortError' ? 'The server took too long to respond.' : 'The server could not be reached.',
    };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Tracks whether the backend API is running.
 *   state      'checking' (first check not finished) | 'online' | 'offline'
 *   everOnline true once the server has answered at least once (used to open the app)
 *   retry()    check again right now
 */
export function useServerHealth() {
  const [state, setState] = useState('checking');
  const [reason, setReason] = useState('');
  const [everOnline, setEverOnline] = useState(false);
  const [busy, setBusy] = useState(false);
  const timer = useRef(null);
  const generation = useRef(0); // lets a newer check cancel an older one

  const check = useCallback(async () => {
    clearTimeout(timer.current);
    const mine = ++generation.current;
    setBusy(true);
    const result = await pingServer();
    if (mine !== generation.current) return;
    setBusy(false);
    if (result.ok) {
      setState('online');
      setReason('');
      setEverOnline(true);
    } else {
      setState('offline');
      setReason(result.reason);
    }
    timer.current = setTimeout(check, result.ok ? RECHECK_ONLINE_MS : RECHECK_OFFLINE_MS);
  }, []);

  useEffect(() => {
    check();
    return () => {
      generation.current += 1;
      clearTimeout(timer.current);
    };
  }, [check]);

  return { state, reason, everOnline, busy, online: state === 'online', retry: check };
}

/** Small status pill shown in the page header. */
export function ServerBadge({ server }) {
  const label =
    server.state === 'online' ? 'Server online' : server.state === 'offline' ? 'Server offline' : 'Checking server…';
  return (
    <span className={`server-badge server-badge-${server.state}`} role="status">
      <span className="server-dot" /> {label}
    </span>
  );
}

/** Shown instead of the steps until the server has answered for the first time. */
export function ServerGate({ server }) {
  if (server.state === 'checking') {
    return (
      <div className="server-gate">
        <h2>Connecting…</h2>
        <p className="instructions">Checking that the AgriVision server is running.</p>
      </div>
    );
  }
  return (
    <div className="server-gate server-gate-down">
      <h2>The server isn't running right now</h2>
      <p className="instructions">
        We can't start a crop-health check until the AgriVision server is back. This is on our side - nothing you
        entered is lost. We are trying again automatically, so you can leave this page open.
      </p>
      <p className="server-reason">{server.reason}</p>
      <button className="btn btn-primary" onClick={server.retry} disabled={server.busy}>
        {server.busy ? 'Checking…' : 'Try again now'}
      </button>
    </div>
  );
}
