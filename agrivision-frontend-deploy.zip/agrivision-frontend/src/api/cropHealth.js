/**
 * Client for the AgriVision Crop Health Service (FastAPI).
 *
 *   POST /fields                          register a drawn polygon -> { field_id }
 *   POST /jobs/crop-health/run            run the satellite + reasoning job
 *   GET  /jobs/crop-health/fields/{id}/latest   last successful result
 *
 * In dev, API_BASE is '' and Vite proxies these paths to the server
 * (see vite.config.js), so the browser never makes a cross-origin call.
 * For a production build set VITE_API_BASE_URL (and enable CORS on the API).
 */
export const API_BASE = (import.meta.env.VITE_API_BASE_URL ?? '').replace(/\/$/, '');

// The run endpoint is synchronous (it downloads Sentinel-2 scenes), so allow a long wait.
const RUN_TIMEOUT_MS = 5 * 60 * 1000;

export class ApiError extends Error {
  constructor(message, { status, detail } = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.detail = detail;
  }
}

function formatDetail(detail) {
  if (!detail) return '';
  if (typeof detail === 'string') return detail;
  // FastAPI 422: [{ loc: [...], msg: '...' }, ...]
  if (Array.isArray(detail)) {
    return detail.map((d) => `${(d.loc || []).join('.')}: ${d.msg}`).join('; ');
  }
  return JSON.stringify(detail);
}

async function request(path, { method = 'GET', body, timeoutMs = 30000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let response;
  try {
    response = await fetch(API_BASE + path, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
  } catch (err) {
    if (err.name === 'AbortError') {
      throw new ApiError('The request timed out. The server may still be processing — try "Load last result" in a minute.');
    }
    throw new ApiError(
      `Could not reach the server (${err.message}). Check that the API is running and that CORS / the dev proxy is set up.`
    );
  } finally {
    clearTimeout(timer);
  }

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    const detail = formatDetail(data?.detail ?? data);
    const friendly =
      response.status >= 500
        ? 'The server had a problem with that request. Please try again in a moment.'
        : detail;
    throw new ApiError(friendly || `Server responded with status ${response.status}`, {
      status: response.status,
      detail: data,
    });
  }
  return data;
}

/** points: [[lat, lng], ...]  ->  { field_id, ... } */
export function registerField(points, name = 'Field drawn on map') {
  return request('/fields', {
    method: 'POST',
    body: {
      name,
      polygon: points.map(([lat, lng]) => ({ latitude: lat, longitude: lng })),
    },
  });
}

/** Queue a job. Returns { job_id, field_id, status } straight away. */
export function startCropHealth(fieldId, startDate, endDate) {
  return request('/jobs/crop-health/start', {
    method: 'POST',
    body: { field_id: fieldId, start_date: startDate, end_date: endDate },
  });
}

/** Poll a queued job: { status: 'running' } until done, then the full result. */
export function getJob(jobId) {
  return request(`/jobs/crop-health/jobs/${encodeURIComponent(jobId)}`);
}

/** (Older blocking call, no longer used.) Dates are 'YYYY-MM-DD'. */
export function runCropHealth(fieldId, startDate, endDate) {
  return request('/jobs/crop-health/run', {
    method: 'POST',
    body: { field_id: fieldId, start_date: startDate, end_date: endDate },
    timeoutMs: RUN_TIMEOUT_MS,
  });
}

/** Returns the stored result JSON (has `health_score`), or throws ApiError(404). */
export function getLatestResult(fieldId) {
  return request(`/jobs/crop-health/fields/${encodeURIComponent(fieldId)}/latest`);
}
